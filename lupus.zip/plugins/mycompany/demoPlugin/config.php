<?php
/**
 * config file
 */
return [
    'setting-example' => 'I love Phile!'
];
