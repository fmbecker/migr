<?php
/**
 * the configuration file
 */

return array(
    'handler'             => \Phile\Plugin\Phile\ErrorHandler\Plugin::HANDLER_ERROR_LOG
);
