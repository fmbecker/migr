<?php
/**
 * config file
 */
$config = array();

return $config;
