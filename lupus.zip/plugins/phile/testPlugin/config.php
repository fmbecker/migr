<?php

return [
    'A' => 'X',
    'B' => 'B'
];
