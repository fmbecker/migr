<!--
Title: Home
Description: This description will go in the meta description tag
Template: page_home
-->



Das U-Team wurde 1979 als "Verein für Jugendbegegnung" gegründet. Sehr bald fand das Team Interesse an der Licht- und Tontechnik und zog als mobile Diskothek durch die Städte.

Inzwischen hat sich aus der mobilen Diskothek ein Anbieter für Veranstaltungstechnik entwickelt, der aus seiner langjährigen Branchenerfahrung schöpfen kann. Durch Engagement und Ehrgeiz hat es das Team geschafft, einige namhafte Kunden an sich zu binden. Dabei erstreckt sich das Betätigungsfeld von der kleinen Betriebsfeier, über große Open Airs (Band & Disco),
bis hin zur Produktpräsentation.

Der Vorteil, den das U-Team dem Veranstalter bringt, ist klar: Wir bieten professionelles Equipment, Knowhow und Innovation zu fairen Preisen an. Außerdem sind wir für den Kunden auch außerhalb der üblichen "Geschäftszeiten" telefonisch erreichbar.

Es ist egal, ob Sie Equipment für eine kleine Party suchen, eine Disco oder ein Open-Air planen, oder einfach die richtige Technik für Ihre Veranstaltung benötigen. Melden Sie sich.
Wir finden bestimmt eine Lösung ...
