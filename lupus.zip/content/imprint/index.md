<!--
Title: Impressum
Order: 1
Template: page_imprint
-->

Anschrift:

U-Team Korntal e.V.
Weilimdorfer Str. 42
70825 Korntal-Münchingen
Tel.: 0711/ 83 25 40
Fax: 0711/ 83 38 88
E-Mail: info@u-team.de
Vorstand:
Thilo Goll (1. Vorsitzender)
Luca Kampschulte (2. Vorsitzender)
Sven Hellebrand (3. Vorsitzender)