<?php

/**
 * Set configuration of your phile installation.
 *
 * You can also overwrite Phile-defaults here.
 */
$config = [];

/**
 * encryption key
 */
$config['encryptionKey'] = '{P=SvWgYmYs8!jt1?cvlt=W78i6!7oM6L[tx4LaX=9aTCIr}A[vSc0eRg{Zv09eB';

/**
 * page title
 */
$config['site_title'] = 'U-Team Korntal';

/**
 * default theme
 */
$config['theme'] = 'default';



//$config['pages_order_by'] = 'meta:order';
$config['pages_order_by'] = 'page.title';
//$config['pages_order']= 'desc';



/**
 * template engine
 */
$config['plugins']=[

'phile\\templateTwig' => ['active' => true],
/**
 * cache engine
 */
 'phile\\phpFastCache' => ['active' => true],
/**
 * persistent data storage
 */
 'phile\\simpleFileDataPersistence' => ['active' => true],
 ];


$config['plugins']['siezi\\phileContactForm'] = ['active' => true];
$config['plugins']['siezi\\phileContactForm']['recipient-email'] = 'info@uteam.de';

return $config;
