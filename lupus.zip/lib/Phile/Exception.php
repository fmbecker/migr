<?php
/**
 * Created by PhpStorm.
 * User: franae
 * Date: 30/10/13
 * Time: 14:47
 */

namespace Phile;

/**
 * the Exception class
 *
 * @author     Frank Nägler
 * @link       https://philecms.com
 * @license    http://opensource.org/licenses/MIT
 * @package    Phile
 * @deprecated since 1.4 will be removed
 * @use        \Phile\Exception\AbstractException
 */
class Exception extends \Phile\Exception\AbstractException
{
}
