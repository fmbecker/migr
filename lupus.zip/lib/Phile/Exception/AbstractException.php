<?php
/**
 * Created by PhpStorm.
 * User: franae
 * Date: 30/10/13
 * Time: 14:47
 */

namespace Phile\Exception;

/**
 * Class AbstarctException
 *
 * @author  Frank Nägler
 * @link    https://philecms.com
 * @license http://opensource.org/licenses/MIT
 *
 * @package Phile\Exception
 */
class AbstractException extends \Exception
{

}
